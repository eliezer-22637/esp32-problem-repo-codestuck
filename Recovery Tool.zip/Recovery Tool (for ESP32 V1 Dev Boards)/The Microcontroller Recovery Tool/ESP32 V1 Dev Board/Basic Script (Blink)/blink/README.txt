Steps:
1. Change directory to this path using this command:
cd C:\Users\(User Name)\Downloads\Recovery Tool\The Microcontroller Recovery Tool\ESP32 V1 Dev Board\Basic Script (Blink)\blink
Change the (User Name in the command with your User Name
2. Write this command to the command prompt:
arduino-cli compile --fqbn esp32:esp32:esp32 "C:\Users\(User Name)\Downloads\Recovery Tool\The Microcontroller Recovery Tool\ESP32 V1 Dev Board\Basic Script (Blink)\blink\blink.ino"
3. Wait until complete
4. Write this command to upload it:
arduino-cli upload -p COM6 --fqbn esp32:esp32:esp32 "C:\Users\(User Name)\Downloads\Recovery Tool\The Microcontroller Recovery Tool\ESP32 V1 Dev Board\Basic Script (Blink)\blink\blink.ino"
Change COM6 with your COM port
5. If needed, press and hold the BOOT button when the command prompt says connecting..., then release the BOOT button when it says Writing at...
Otherwise, skip this step
6. Wait until completed